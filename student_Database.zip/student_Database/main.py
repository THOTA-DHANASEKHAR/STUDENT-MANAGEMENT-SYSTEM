def calculate_percentage(marks_obtained, total_marks):
    percentage = (marks_obtained / total_marks) * 100
    return percentage

def assign_grade(mark):
    if mark >= 91:
        return "S"
    elif mark >= 81:
        return "A"
    elif mark >= 71:
        return "B"
    elif mark >= 61:
        return "C"
    elif mark >= 51:
        return "D"
    elif mark >= 50:
        return "E"
    else:
        return "F"


marks_list = []
a=[24,67,45,89]
for subject in a:
    b=assign_grade(subject)
    marks_list.append(b)
print(marks_list)



