from django.apps import AppConfig


class StudentAppConfig(AppConfig):
    name = 'student_app'
